Plugin Name: |CelMod|
Plugin Version: 1.5.0.0
Plugin Description: The |CelMod| plugin was originally created by Celsius in 2009. The plugin was alive 2009-2012. It was dropped by the creator for reasons unknown. Many other projects since then have tried to recapture the essence of the original. This is just a update/fix to the code, with new features added. It is coded by FusionLock (http://steamcommunity.com/profiles/76561198054654475). In this version, it has been recoded but is very similar to the original code. Like, previously stated, features have been added.
Plugin Convars: cm_prop_limit, cm_cel_limit
Plugin Commands:
sm_spawn
sm_delete
sm_deleteall
sm_freeze
sm_unfreeze
sm_fly
sm_internet
sm_seturl
sm_color
sm_hudcolor
sm_owner
sm_amt
sm_solid
sm_rotate
sm_flip
sm_roll
sm_straight
sm_smove
sm_colorall
sm_door
sm_ignite
sm_sound
sm_music
Plugin Changelog:
1.5.0.0 - Released the plugin publicly.